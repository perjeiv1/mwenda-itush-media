declare const RangeError: RangeErrorConstructor;

export = RangeError;
